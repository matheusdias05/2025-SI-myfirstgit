

declare global {

interface Campeonato {
    id: number;
    nome: string;
    categoria: string;
    tipo: string;
    dataInicio: string;
    dataFim: string;
  }
  
}

export {}